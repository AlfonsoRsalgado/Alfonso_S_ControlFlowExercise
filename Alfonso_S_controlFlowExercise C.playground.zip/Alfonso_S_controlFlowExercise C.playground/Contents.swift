
var carcollection: [String] = ["blueRaceCar", "redCar", "greenCar", "bigTruck", "airplane"]

print("my car collection has \(carcollection.count)")

for item in carcollection {
    print(item)
}

